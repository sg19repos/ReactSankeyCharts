const messages = {
    en: {
        greeting: 'Hello! this is the income expenditure chart represented in Sankey diagram',
        switchMessage: 'Switch your languages',
        addNewItem: 'Add new item',
        addIncomeExp: 'Add new income - expenditure values',
    },
    fr: {
        greeting:
            'Bonjour! voici le tableau des dépenses de revenus représenté dans le diagramme de Sankey',
        switchMessage: 'Changez vos langues',
        addNewItem: 'Ajouter un nouvel élément',
        addIncomeExp: 'Ajouter de nouveaux revenus - valeurs des dépenses',
    },
    it: {
        greeting:
            'Ciao! questo è il grafico delle spese per le entrate rappresentato nel diagramma di Sanke',
        switchMessage: 'Cambia le tue lingue',
        addNewItem: 'Aggiungi un nuovo elemento',
        addIncomeExp: 'Aggiungi nuovo reddito - valori di spesa',
    },
};

export default messages;
