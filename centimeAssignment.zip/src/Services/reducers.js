import {
    FETCH_EXPENSE_DATA_REQUEST,
    FETCH_EXPENSE_DATA_SUCCESS,
    ADD_NEW_EXPENSE_DATA_REQUEST,
    ADD_NEW_EXPENSE_DATA_SUCCESS,
    DELETE_EXPENSE_DATA_REQUEST,
    DELETE_EXPENSE_DATA_SUCCESS,
} from './actionTypes';

const deducePayload = (action) => {
    return action.payload;
};
export default function expenseDataReducer(state = { expenseData: [] }, action) {
    switch (action.type) {
        case FETCH_EXPENSE_DATA_REQUEST:
            return { expenseData: deducePayload(action) };
        case FETCH_EXPENSE_DATA_SUCCESS:
            return { expenseData: deducePayload(action) };
        case ADD_NEW_EXPENSE_DATA_REQUEST:
            return { expenseData: deducePayload(action) };
        case ADD_NEW_EXPENSE_DATA_SUCCESS:
            return { expenseData: deducePayload(action) };
        case DELETE_EXPENSE_DATA_REQUEST:
            return { expenseData: deducePayload(action) };
        case DELETE_EXPENSE_DATA_SUCCESS:
            return { expenseData: deducePayload(action) };
        default:
            return state;
    }
}
