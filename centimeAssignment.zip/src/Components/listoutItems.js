import React from 'react';
import InteractiveList from './listItems';

const ListOutItems = ({ expenseData, handleDelete }) => {
    return (
        <div>
            {expenseData
                ? expenseData.map((element) => {
                      return expenseData.indexOf(element) !== 0 ? (
                          <div key={expenseData.indexOf(element)}>
                              <InteractiveList
                                  listDetails={element}
                                  id={expenseData.indexOf(element)}
                                  handleDelete={handleDelete}
                              />
                          </div>
                      ) : null;
                  })
                : 'null'}
        </div>
    );
};

export default ListOutItems;
