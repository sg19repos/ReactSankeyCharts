import React from 'react';
import { HeaderLogo } from '../assets/images/centimelogo.png';

const Header = () => {
    return (
        <div className="header-logo" style={{ paddingTop: '5%' }}>
            <img src="/assets/images/centimelogo.png" alt="Logo" width="200px" />
        </div>
    );
};

export default Header;
