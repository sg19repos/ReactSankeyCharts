import React, { useEffect, useState } from 'react';
import { connect } from 'react-redux';
import { fetchExpenseDataRequest, deleteExpenseDataRequest } from '../Services/actions';
import { expenseDataSelectors } from '../Services/selectors';
import { Chart } from 'react-google-charts';
import Header from './header';
import { FormattedMessage } from 'react-intl';
import coreStyles from '../styles/styles.css';
import SwitchLanguages from './switchLanguage';
import CreateNewItem from './createNewItem';
import ListOutItems from './listoutItems';
import Grid from '@material-ui/core/Grid';
import { makeStyles } from '@material-ui/core/styles';

function SankeyChartHome({
    expenseData,
    dispatchExpenseData,
    handleSwitch,
    selectedLanguage,
    dispatchDeleteExpenseData,
}) {
    useEffect(() => {
        dispatchExpenseData();
    }, []);

    const [spacing, setSpacing] = useState(2);

    const useStyles = makeStyles((theme) => ({
        root: {
            flexGrow: 1,
        },
        paper: {
            height: 440,
            width: 500,
        },
        control: {
            padding: theme.spacing(2),
        },
    }));
    const classes = useStyles();

    const handleDelete = (key) => {
        dispatchDeleteExpenseData(expenseData, key);
    };

    return (
        <div className={coreStyles.mainContent}>
            <Header />
            <SwitchLanguages
                style={{ transform: "translate('50%, -50%')" }}
                handleSwitch={handleSwitch}
                selectedLanguage={selectedLanguage}
            />
            <FormattedMessage id="greeting" />
            <CreateNewItem expenseData={expenseData} />

            <Grid container className={classes.root} spacing={2}>
                <Grid item xs={12}>
                    <Grid container justify="center" spacing={spacing}>
                        <Grid key={1} item>
                            <ListOutItems expenseData={expenseData} handleDelete={handleDelete} />
                        </Grid>
                        <Grid key={2} item>
                            {expenseData ? (
                                <Chart
                                    width={600}
                                    height={'400px'}
                                    chartType="Sankey"
                                    loader={<div>Loading Chart</div>}
                                    data={expenseData}
                                    rootProps={{ 'data-testid': '1' }}
                                />
                            ) : null}
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
        </div>
    );
}
const mapStateToProps = (state) => ({
    expenseData: expenseDataSelectors(state),
});

const mapDispatchToProps = (dispatch) => ({
    dispatchExpenseData: () => {
        dispatch(fetchExpenseDataRequest());
    },
    dispatchDeleteExpenseData: (expenseData, key) => {
        dispatch(deleteExpenseDataRequest(expenseData, key));
    },
});

export default connect(mapStateToProps, mapDispatchToProps)(SankeyChartHome);
