import React, { useState } from 'react';
import styles from './styles/styles.css';
import { IntlProvider, FormattedMessage } from 'react-intl';
import messages from './Core/i18n';
import { HashRouter, Route, Switch } from 'react-router-dom';
import SankeyChartHome from './Components';

function App() {
    const [locale, setLocale] = useState(
        localStorage.getItem('localValue') ? localStorage.getItem('localValue') : 'en',
    );
    const handleSwitch = (language) => {
        setLocale(language);
        localStorage.setItem('localValue', language);
    };
    return (
        <IntlProvider locale={locale} messages={messages[locale]}>
            <HashRouter>
                <Switch>
                    <Route
                        exact={true}
                        path="/"
                        component={() => (
                            <SankeyChartHome
                                handleSwitch={handleSwitch}
                                selectedLanguage={locale}
                            />
                        )}
                    />
                </Switch>
            </HashRouter>
        </IntlProvider>
    );
}

export default App;
