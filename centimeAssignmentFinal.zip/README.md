# Sankey-charts build in material ui and react-redux

## Features

-   React 16
-   Webpack 4
-   Babel 7
-   Hot Module Replacement
-   Internationalization
-   Redux
-   Sankey Charts by Google

## Installation

-   cd sankeycharts
-   npm install
-   npm start
-   visit `http://localhost:8080/`
