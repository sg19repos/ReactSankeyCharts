import React, { Fragment, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import TextField from '@material-ui/core/TextField';
import Dialog from '@material-ui/core/Dialog';
import DialogTitle from '@material-ui/core/DialogTitle';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogActions from '@material-ui/core/DialogActions';
import Button from '@material-ui/core/Button';
import Autocomplete, { createFilterOptions } from '@material-ui/lab/Autocomplete';
import { connect } from 'react-redux';
import { fetchExpenseDataRequest, addExpenseDataRequest } from '../Services/actions';
import { expenseDataSelectors } from '../Services/selectors';
import PostAddOutlinedIcon from '@material-ui/icons/PostAddOutlined';
import SaveIcon from '@material-ui/icons/Save';
import IconButton from '@material-ui/core/IconButton';
import { makeStyles } from '@material-ui/core/styles';
import { FormattedMessage } from 'react-intl';

const filter = createFilterOptions();

function CreateNewItem({ expenseData, dispatchExpenseData, dispatchAddNewExpenseData }) {
    const [item, setItem] = useState(null);
    const [incomeValue, setIncomeValue] = useState(null);
    const [expenditureValue, setExpenditureValue] = useState(null);
    const [open, toggleOpen] = useState(false);
    const useStyles = makeStyles((theme) => ({
        button: {
            margin: theme.spacing(1),
        },
    }));
    const classes = useStyles();

    const handleClose = () => {
        setDialogValue({
            income: '',
            expenditure: '',
        });

        toggleOpen(false);
    };

    useEffect(() => {
        dispatchExpenseData();
    }, []);

    const [dialogValue, setDialogValue] = useState({
        income: '',
        expenditure: '',
    });

    const handleSubmit = (event) => {
        event.preventDefault();
        setItem({
            income: incomeValue.income,
            expenditure: expenditureValue.expenditure,
            amount: dialogValue.amount,
        });

        expenseData.push([
            incomeValue.income,
            expenditureValue.expenditure,
            parseInt(dialogValue.amount, 10),
        ]);
        dispatchAddNewExpenseData(JSON.stringify(expenseData));
        localStorage.setItem('mockData', JSON.stringify(expenseData));
        handleClose();
    };

    const incomeItems = [{ income: 'income1' }, { income: 'income2' }];
    const expenditureItems = [
        { expenditure: 'House Rent' },
        { expenditure: 'Medical Expense' },
        { expenditure: 'Travel Expense' },
    ];

    return (
        <Fragment>
            <Button
                variant="contained"
                color="default"
                size="small"
                className={classes.button}
                startIcon={<PostAddOutlinedIcon />}
                onClick={() => toggleOpen(true)}
            >
                <FormattedMessage id="addNewItem" />
            </Button>

            <Dialog open={open} onClose={handleClose} aria-labelledby="form-dialog-title">
                <form onSubmit={handleSubmit}>
                    <DialogTitle id="form-dialog-title">
                        <FormattedMessage id="addNewItem" />
                    </DialogTitle>
                    <DialogContent>
                        <DialogContentText>
                            <FormattedMessage id="addIncomeExp" />
                        </DialogContentText>

                        <Autocomplete
                            value={incomeValue}
                            onChange={(event, newValue) => {
                                if (typeof newValue === 'string') {
                                    setTimeout(() => {
                                        toggleOpen(true);
                                        setDialogValue({
                                            income: newValue,
                                            expenditure: '',
                                        });
                                    });
                                } else if (newValue && newValue.inputValue) {
                                    toggleOpen(true);
                                    setIncomeValue(newValue);
                                } else {
                                    setIncomeValue(newValue);
                                }
                            }}
                            filterOptions={(options, params) => {
                                const filtered = filter(options, params);

                                if (params.inputValue !== '') {
                                    filtered.push({
                                        inputValue: params.inputValue,
                                        income: `${params.inputValue}`,
                                    });
                                }

                                return filtered;
                            }}
                            id="free-solo-dialog-demo"
                            options={incomeItems}
                            getOptionLabel={(option) => {
                                if (typeof option === 'string') {
                                    return option;
                                }
                                if (option.inputValue) {
                                    return option.inputValue;
                                }
                                return option.income;
                            }}
                            selectOnFocus
                            clearOnBlur
                            handleHomeEndKeys
                            renderOption={(option) => option.income}
                            style={{ width: 300 }}
                            freeSolo
                            renderInput={(params) => (
                                <TextField
                                    required
                                    {...params}
                                    label="Add new income"
                                    variant="outlined"
                                />
                            )}
                        />
                        <Autocomplete
                            value={expenditureValue}
                            onChange={(event, newValue) => {
                                if (typeof newValue === 'string') {
                                    setTimeout(() => {
                                        toggleOpen(true);
                                        setDialogValue({
                                            income: newValue,
                                            expenditure: '',
                                        });
                                    });
                                } else if (newValue && newValue.inputValue) {
                                    toggleOpen(true);
                                    setExpenditureValue(newValue);
                                } else {
                                    setExpenditureValue(newValue);
                                }
                            }}
                            filterOptions={(options, params) => {
                                const filtered = filter(options, params);

                                if (params.inputValue !== '') {
                                    filtered.push({
                                        inputValue: params.inputValue,
                                        expenditure: `${params.inputValue}`,
                                    });
                                }

                                return filtered;
                            }}
                            id="free-solo-dialog-demo"
                            options={expenditureItems}
                            getOptionLabel={(option) => {
                                if (typeof option === 'string') {
                                    return option;
                                }
                                if (option.inputValue) {
                                    return option.inputValue;
                                }
                                return option.expenditure;
                            }}
                            selectOnFocus
                            clearOnBlur
                            handleHomeEndKeys
                            renderOption={(option) => option.expenditure}
                            style={{ width: 300 }}
                            freeSolo
                            renderInput={(params) => (
                                <TextField
                                    required
                                    {...params}
                                    label="Add new expenditure"
                                    variant="outlined"
                                />
                            )}
                        />
                        <TextField
                            margin="dense"
                            id="name"
                            value={dialogValue.amount}
                            onChange={(event) =>
                                setDialogValue({ ...dialogValue, amount: event.target.value })
                            }
                            label="Amount"
                            type="number"
                            required={true}
                        />
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={handleClose} color="primary">
                            Cancel
                        </Button>
                        <Button type="submit" color="primary">
                            Add
                        </Button>
                    </DialogActions>
                </form>
            </Dialog>
        </Fragment>
    );
}

const mapStateToProps = (state) => ({
    expenseData: expenseDataSelectors(state),
});

const mapDispatchToProps = (dispatch) => ({
    dispatchExpenseData: () => {
        dispatch(fetchExpenseDataRequest());
    },
    dispatchAddNewExpenseData: (expenseData) => {
        dispatch(addExpenseDataRequest(expenseData));
    },
});

CreateNewItem.propTypes = {
    dispatchAddNewExpenseData: PropTypes.func.isRequired,
    expenseData: PropTypes.arrayOf(PropTypes.array),
    dispatchExpenseData: PropTypes.func.isRequired,
};

CreateNewItem.defaultProps = {
    expenseData: undefined,
};

export default connect(mapStateToProps, mapDispatchToProps)(CreateNewItem);
