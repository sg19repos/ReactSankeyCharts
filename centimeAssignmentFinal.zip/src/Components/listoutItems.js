import React from 'react';
import PropTypes from 'prop-types';
import InteractiveList from './listItems';

const ListOutItems = ({ expenseData, handleDelete }) => {
    return (
        <div>
            {expenseData
                ? expenseData.map((element) => {
                      return expenseData.indexOf(element) !== 0 ? (
                          <div key={expenseData.indexOf(element)}>
                              <InteractiveList
                                  listDetails={element}
                                  id={expenseData.indexOf(element)}
                                  handleDelete={handleDelete}
                              />
                          </div>
                      ) : null;
                  })
                : 'No expenses added yet'}
        </div>
    );
};
ListOutItems.propTypes = {
    expenseData: PropTypes.arrayOf(PropTypes.array),
    handleDelete: PropTypes.func.isRequired,
};

ListOutItems.defaultProps = {
    expenseData: undefined,
};

export default ListOutItems;
