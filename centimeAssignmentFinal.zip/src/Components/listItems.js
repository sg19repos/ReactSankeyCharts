import React from 'react';
import PropTypes from 'prop-types';
import { makeStyles } from '@material-ui/core/styles';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Divider from '@material-ui/core/Divider';
import InboxIcon from '@material-ui/icons/Inbox';
import ArrowRightOutlinedIcon from '@material-ui/icons/ArrowRightOutlined';
import DeleteIcon from '@material-ui/icons/Delete';
import ListItemSecondaryAction from '@material-ui/core/ListItemSecondaryAction';
import IconButton from '@material-ui/core/IconButton';

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
        maxWidth: 360,
        backgroundColor: '#ddd',
        color: '#000',
    },
    fonts: {
        fontFamily: 'Poppins !important',
        boxShadow:
            '0px 3px 1px -2px rgba(0,0,0,0.2), 0px 2px 2px 0px rgba(0,0,0,0.14), 0px 1px 5px 0px rgba(0,0,0,0.12)',
    },
}));

export default function InteractiveList({ listDetails, id, handleDelete }) {
    const classes = useStyles();

    return (
        <div className={classes.root}>
            <List component="nav" aria-label="main mailbox folders" className={classes.fonts}>
                <ListItem button style={{ height: '25px' }}>
                    <ListItemIcon>
                        <InboxIcon />
                    </ListItemIcon>
                    <ListItemText
                        style={{ textTransform: 'capitalize', fontFamily: 'Poppins !important' }}
                        primary={listDetails[0]}
                    />
                    <ListItemText primary={<ArrowRightOutlinedIcon />} />

                    <ListItemText
                        style={{ textTransform: 'capitalize', fontFamily: 'Poppins !important' }}
                        secondary={listDetails[1]}
                    />
                    <ListItemText primary={<ArrowRightOutlinedIcon />} />

                    <ListItemText
                        style={{ textTransform: 'capitalize' }}
                        primary={listDetails[2]}
                    />
                    <ListItemSecondaryAction>
                        <IconButton edge="end" aria-label="delete" onClick={() => handleDelete(id)}>
                            <DeleteIcon />
                        </IconButton>
                    </ListItemSecondaryAction>
                </ListItem>
            </List>
            <Divider />
        </div>
    );
}

InteractiveList.propTypes = {
    listDetails: PropTypes.arrayOf(PropTypes.oneOfType([PropTypes.string, PropTypes.number]))
        .isRequired,
    id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    handleDelete: PropTypes.func.isRequired,
};

InteractiveList.defaultProps = {
    listDetails: undefined,
};
