import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';
import mockData from './mockData.json';

var mock = new MockAdapter(axios);
!localStorage.getItem('mockData')
    ? localStorage.setItem('mockData', JSON.stringify(mockData))
    : null;
const expenseData = localStorage.getItem('mockData');
const fetchExpenseDataApi = {
    async fetchExpenseData(url) {
        mock.onGet(url).reply(200, {
            expenseData: JSON.parse(expenseData).data,
        });
        const response = await axios.get(url).then(function (response) {
            return response.data.expenseData ? response.data.expenseData : JSON.parse(expenseData);
        });

        return response;
    },
};

export default fetchExpenseDataApi;
