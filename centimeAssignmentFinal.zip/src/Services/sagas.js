import { all, call, put, takeEvery } from 'redux-saga/effects';
import {
    FETCH_EXPENSE_DATA_REQUEST,
    ADD_NEW_EXPENSE_DATA_REQUEST,
    DELETE_EXPENSE_DATA_REQUEST,
} from './actionTypes';
import {
    fetchExpenseDataSuccess,
    fetchExpenseDataFailure,
    addExpenseDataSuccess,
    deleteExpenseDataSuccess,
    addExpenseDataFailure,
} from './actions';
import fetchExpenseDataApi from './api';

function* fetchExpenseData() {
    // const endpoint = 'mockUrl';
    // yield put(fetchExpenseDataSuccess(yield call(fetchExpenseDataApi.fetchExpenseData, endpoint)));

    try {
        const endpoint = 'mockUrl';
        yield put(
            fetchExpenseDataSuccess(yield call(fetchExpenseDataApi.fetchExpenseData, endpoint)),
        );
    } catch (e) {
        yield put(fetchExpenseDataFailure(e));
    }
}

function* addNewExpenseDataRequest(expenseData) {
    // yield put(addExpenseDataSuccess(expenseData));

    try {
        yield put(yield put(addExpenseDataSuccess(expenseData)));
    } catch (e) {
        yield put(addExpenseDataFailure(e));
    }
}

function* deleteExpenseDataRequest(key) {
    // yield put(deleteExpenseDataSuccess(key));

    try {
        yield put(deleteExpenseDataSuccess(key));
    } catch (e) {
        yield put(deleteExpenseDataFailure(e));
    }
}

function* addExpenseData() {
    yield takeEvery(FETCH_EXPENSE_DATA_REQUEST, fetchExpenseData);
    yield takeEvery(ADD_NEW_EXPENSE_DATA_REQUEST, addNewExpenseDataRequest);
    yield takeEvery(DELETE_EXPENSE_DATA_REQUEST, deleteExpenseDataRequest);
}

export default function* rootSaga() {
    yield all([addExpenseData()]);
}
