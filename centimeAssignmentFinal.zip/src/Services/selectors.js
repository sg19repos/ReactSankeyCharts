export const expenseDataSelectors = (state) => state.expenseData;
