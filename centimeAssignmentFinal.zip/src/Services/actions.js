import {
    FETCH_EXPENSE_DATA_REQUEST,
    FETCH_EXPENSE_DATA_SUCCESS,
    FETCH_EXPENSE_DATA_FAILURE,
    ADD_NEW_EXPENSE_DATA_REQUEST,
    ADD_NEW_EXPENSE_DATA_SUCCESS,
    ADD_NEW_EXPENSE_DATA_FAILURE,
    DELETE_EXPENSE_DATA_REQUEST,
    DELETE_EXPENSE_DATA_SUCCESS,
    DELETE_EXPENSE_DATA_FAILURE,
} from './actionTypes';

export const fetchExpenseDataRequest = () => {
    return {
        type: FETCH_EXPENSE_DATA_REQUEST,
    };
};

export const fetchExpenseDataSuccess = (expenseData) => {
    return {
        type: FETCH_EXPENSE_DATA_SUCCESS,
        payload: expenseData,
    };
};

export const fetchExpenseDataFailure = (errorMessage) => {
    return {
        type: FETCH_EXPENSE_DATA_FAILURE,
        payload: errorMessage,
    };
};

export const addExpenseDataRequest = (expenseData) => {
    return {
        type: ADD_NEW_EXPENSE_DATA_REQUEST,
        payload: JSON.parse(expenseData),
    };
};

export const addExpenseDataSuccess = (action) => {
    return {
        type: ADD_NEW_EXPENSE_DATA_SUCCESS,
        payload: action.payload,
    };
};

export const addExpenseDataFailure = (errorMessage) => {
    return {
        type: ADD_NEW_EXPENSE_DATA_FAILURE,
        payload: errorMessage,
    };
};

export const deleteExpenseDataRequest = (expenseData, key) => {
    const newExpensData = expenseData.filter((element) => expenseData.indexOf(element) !== key);
    localStorage.setItem('mockData', JSON.stringify(newExpensData));
    return {
        type: DELETE_EXPENSE_DATA_REQUEST,
        payload: newExpensData,
    };
};

export const deleteExpenseDataSuccess = (action) => {
    return {
        type: DELETE_EXPENSE_DATA_SUCCESS,
        payload: action.payload,
    };
};

export const deleteExpenseDataFailure = (errorMessage) => {
    return {
        type: DELETE_EXPENSE_DATA_FAILURE,
        payload: errorMessage,
    };
};
