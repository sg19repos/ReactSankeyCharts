import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import { createStore, applyMiddleware, compose } from 'redux';
import 'regenerator-runtime/runtime';
import 'core-js/stable';
import { Provider } from 'react-redux';
import expenseDataReducer from './Services/reducers';
import createSagaMiddleware from 'redux-saga';
import rootSaga from './Services/sagas';

const title = 'Income - Expenditure Sankey chart';

const sagaMiddleware = createSagaMiddleware();

const composeEnhancers =
    typeof window === 'object' && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__
        ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({})
        : compose;

const enhancer = composeEnhancers(applyMiddleware(sagaMiddleware));

const store = createStore(expenseDataReducer, enhancer);

sagaMiddleware.run(rootSaga);

ReactDOM.render(
    <Provider store={store}>
        <App title={title} />
    </Provider>,
    document.getElementById('app'),
);

module.hot.accept();
